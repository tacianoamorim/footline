package com.g2t.footline.testes;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
	ArbitroTest.class,
	EstadioTest.class
})
public class AllTests {

}
